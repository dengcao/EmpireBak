<?php

declare(strict_types=1);

namespace PhpMyAdmin\ConfigStorage\Features;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


use PhpMyAdmin\Dbal\DatabaseName;
use PhpMyAdmin\Dbal\TableName;

/**
 * @psalm-immutable
 */
final class RecentlyUsedTablesFeature
{
    /** @var DatabaseName */
    public $database;

    /** @var TableName */
    public $recent;

    public function __construct(DatabaseName $database, TableName $recent)
    {
        $this->database = $database;
        $this->recent = $recent;
    }
}
