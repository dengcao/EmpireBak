<?php
/**
 * Setup preferences form
 */

declare(strict_types=1);

namespace PhpMyAdmin\Config\Forms\Setup;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


use PhpMyAdmin\Config\Forms\BaseFormList;

class SetupFormList extends BaseFormList
{
    /** @var string[] */
    protected static $all = [
        'Config',
        'Export',
        'Features',
        'Import',
        'Main',
        'Navi',
        'Servers',
        'Sql',
    ];
    /** @var string */
    protected static $ns = 'PhpMyAdmin\\Config\\Forms\\Setup\\';
}
