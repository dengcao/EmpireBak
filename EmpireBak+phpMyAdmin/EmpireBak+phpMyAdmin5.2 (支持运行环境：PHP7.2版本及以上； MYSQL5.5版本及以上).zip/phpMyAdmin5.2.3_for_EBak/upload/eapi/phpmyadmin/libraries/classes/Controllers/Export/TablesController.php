<?php

declare(strict_types=1);

namespace PhpMyAdmin\Controllers\Export;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


use PhpMyAdmin\Controllers\AbstractController;
use PhpMyAdmin\Controllers\Database\ExportController;
use PhpMyAdmin\ResponseRenderer;
use PhpMyAdmin\Template;

use function __;

final class TablesController extends AbstractController
{
    /** @var ExportController */
    private $exportController;

    public function __construct(ResponseRenderer $response, Template $template, ExportController $exportController)
    {
        parent::__construct($response, $template);
        $this->exportController = $exportController;
    }

    public function __invoke(): void
    {
        if (empty($_POST['selected_tbl'])) {
            $this->response->setRequestStatus(false);
            $this->response->addJSON('message', __('No table selected.'));

            return;
        }

        ($this->exportController)();
    }
}
