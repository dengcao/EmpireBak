<?php

declare(strict_types=1);

namespace PhpMyAdmin\Controllers;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


use PhpMyAdmin\RecentFavoriteTable;

final class RecentTablesListController extends AbstractController
{
    public function __invoke(): void
    {
        if (! $this->response->isAjax()) {
            return;
        }

        $this->response->addJSON([
            'list' => RecentFavoriteTable::getInstance('recent')->getHtmlList(),
        ]);
    }
}
