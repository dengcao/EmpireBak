<?php

declare(strict_types=1);

namespace PhpMyAdmin\ConfigStorage\Features;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


use PhpMyAdmin\Dbal\DatabaseName;
use PhpMyAdmin\Dbal\TableName;

/**
 * @psalm-immutable
 */
final class ConfigurableMenusFeature
{
    /** @var DatabaseName */
    public $database;

    /** @var TableName */
    public $userGroups;

    /** @var TableName */
    public $users;

    public function __construct(DatabaseName $database, TableName $userGroups, TableName $users)
    {
        $this->database = $database;
        $this->userGroups = $userGroups;
        $this->users = $users;
    }
}
