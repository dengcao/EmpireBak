<?php
/**
 * The BerkeleyDB storage engine
 */

declare(strict_types=1);

namespace PhpMyAdmin\Engines;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


/**
 * This is same as BDB
 */
class Berkeleydb extends Bdb
{
}
