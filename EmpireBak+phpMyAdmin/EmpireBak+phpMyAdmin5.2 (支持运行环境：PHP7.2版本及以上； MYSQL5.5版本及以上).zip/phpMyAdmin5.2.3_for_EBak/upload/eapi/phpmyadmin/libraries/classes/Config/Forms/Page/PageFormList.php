<?php
/**
 * Page preferences form
 */

declare(strict_types=1);

namespace PhpMyAdmin\Config\Forms\Page;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


use PhpMyAdmin\Config\Forms\BaseFormList;

class PageFormList extends BaseFormList
{
    /** @var string[] */
    protected static $all = [
        'Browse',
        'DbStructure',
        'Edit',
        'Export',
        'Import',
        'Navi',
        'Sql',
        'TableStructure',
    ];
    /** @var string */
    protected static $ns = 'PhpMyAdmin\\Config\\Forms\\Page\\';
}
