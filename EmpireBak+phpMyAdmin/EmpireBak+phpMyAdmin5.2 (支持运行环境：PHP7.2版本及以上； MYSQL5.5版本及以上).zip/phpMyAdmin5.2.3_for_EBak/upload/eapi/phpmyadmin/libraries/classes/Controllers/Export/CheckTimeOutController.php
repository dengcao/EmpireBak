<?php

declare(strict_types=1);

namespace PhpMyAdmin\Controllers\Export;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


use PhpMyAdmin\Controllers\AbstractController;

final class CheckTimeOutController extends AbstractController
{
    public function __invoke(): void
    {
        $this->response->setAjax(true);

        if (isset($_SESSION['pma_export_error'])) {
            unset($_SESSION['pma_export_error']);
            $this->response->addJSON('message', 'timeout');

            return;
        }

        $this->response->addJSON('message', 'success');
    }
}
