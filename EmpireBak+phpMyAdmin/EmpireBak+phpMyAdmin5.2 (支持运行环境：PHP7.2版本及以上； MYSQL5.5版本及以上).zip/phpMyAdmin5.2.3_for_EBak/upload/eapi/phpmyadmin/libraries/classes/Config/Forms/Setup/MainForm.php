<?php
/**
 * User preferences form
 */

declare(strict_types=1);

namespace PhpMyAdmin\Config\Forms\Setup;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


class MainForm extends \PhpMyAdmin\Config\Forms\User\MainForm
{
    /**
     * @return array
     */
    public static function getForms()
    {
        $result = parent::getForms();
        /* Following are not available to user */
        $result['Startup'][] = 'ShowPhpInfo';
        $result['Startup'][] = 'ShowChgPassword';

        return $result;
    }
}
