<?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php
/* $Id: merge.lib.php 8104 2005-12-07 10:49:43Z cybot_tm $ */
// vim: expandtab sw=4 ts=4 sts=4:

class PMA_StorageEngine_merge extends PMA_StorageEngine
{
}

?>
