<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * The BerkeleyDB storage engine
 *
 * @package PhpMyAdmin-Engines
 */
namespace PhpMyAdmin\Engines;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


/**
 * This is same as BDB
 *
 * @package PhpMyAdmin-Engines
 */
class Berkeleydb extends Bdb
{
}

