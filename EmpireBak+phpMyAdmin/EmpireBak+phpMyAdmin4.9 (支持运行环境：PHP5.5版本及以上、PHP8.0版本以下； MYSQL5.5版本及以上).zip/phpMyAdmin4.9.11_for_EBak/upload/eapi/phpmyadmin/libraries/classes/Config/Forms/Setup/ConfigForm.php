<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * User preferences form
 *
 * @package PhpMyAdmin
 */
namespace PhpMyAdmin\Config\Forms\Setup;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


use PhpMyAdmin\Config\Forms\BaseForm;

class ConfigForm extends BaseForm
{
    public static function getForms()
    {
        return array(
            'Config' => array(
                'DefaultLang',
                'ServerDefault'
            ),
        );
    }
}
