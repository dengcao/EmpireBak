<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Interface for the transformations plugins
 *
 * @package PhpMyAdmin
 */
namespace PhpMyAdmin\Plugins;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


/**
 * Provides a common interface that will have to be implemented by all of the
 * transformations plugins.
 *
 * @package PhpMyAdmin
 */
interface TransformationsInterface
{
    /**
     * Gets the transformation description
     *
     * @return string
     */
    public static function getInfo();

    /**
     * Gets the specific MIME type
     *
     * @return string
     */
    public static function getMIMEType();

    /**
     * Gets the specific MIME subtype
     *
     * @return string
     */
    public static function getMIMESubtype();

    /**
     * Gets the transformation name of the specific plugin
     *
     * @return string
     */
    public static function getName();
}

