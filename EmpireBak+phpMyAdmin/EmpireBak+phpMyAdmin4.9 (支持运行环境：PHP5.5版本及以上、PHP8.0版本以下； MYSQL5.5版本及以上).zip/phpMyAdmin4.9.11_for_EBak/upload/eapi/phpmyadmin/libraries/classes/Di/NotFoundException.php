<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Holds the PhpMyAdmin\Di\NotFoundException class
 *
 * @package PhpMyAdmin\Di
 */
namespace PhpMyAdmin\Di;
?><?php
if(!defined('InEmpireBak'))
{
	@include_once('../../../../ebma.php');
	if(!defined('EbakFourCheck'))
	{
		exit();
	}
	if(EbakFourCheck==''||EbakFourCheck=='EbakFourCheck')
	{
		exit();
	}
	if(EbakFourCheck<>'dg'.$_COOKIE['qebak_efourcheck'])
	{
		exit();
	}
}
if(!defined('InEmpireApi'))
{
	exit();
}
?><?php


use Psr\Container\NotFoundExceptionInterface;

/**
 * Class NotFoundException
 *
 * @package PhpMyAdmin\Di
 */
class NotFoundException extends ContainerException implements NotFoundExceptionInterface
{

}
